
  # MBA- IA

  This is a code bundle for MBA- IA. The original project is available at https://www.figma.com/design/CKuh54Ze31zV9kuOEmncJf/MBA--IA.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  