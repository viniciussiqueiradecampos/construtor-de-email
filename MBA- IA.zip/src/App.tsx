import { PageBuilder } from './components/PageBuilder';

export default function App() {
  return <PageBuilder />;
}
